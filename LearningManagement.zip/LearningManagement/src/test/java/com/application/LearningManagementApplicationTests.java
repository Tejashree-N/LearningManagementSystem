package com.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
