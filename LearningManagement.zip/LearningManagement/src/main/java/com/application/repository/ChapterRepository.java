package com.application.repository;

import org.springframework.data.repository.CrudRepository;

import com.application.entity.Chapter;

import java.util.List;

public interface ChapterRepository extends CrudRepository<Chapter, Integer>
{
	public List<Chapter> findByCoursename(String Coursename);
	
}